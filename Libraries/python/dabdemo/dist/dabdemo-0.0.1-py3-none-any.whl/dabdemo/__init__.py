# Filename: __init__.py
__version__ = '0.0.1'
__author__ = 'marco.ferraro'

import sys, os

sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))